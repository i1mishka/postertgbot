API_ID = 99999999 #APP TELEGRAM ID - 
API_HASH = "HASH" # APP TELEGRAM HASH - 
BOT_TOKEN = "API" # BOT API - 
DATABASE_PATH = 'database.db'
OPEN_AI_KEY = 'API KEY' # OPEN AI KEY - 


language_codes = {
    'Ukranian': 'украинский',
    'Russian': 'русский',
    'English': 'английский',
    'Indian': 'индийский',
    'Italian': 'итальянский',
    'Brasilian': 'бразильский',
    'Germany': 'немецкий',
    'Indonesian': 'индонезийский'
}